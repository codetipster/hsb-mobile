import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_en.dart';

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'gen_l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('en')
  ];

  /// No description provided for @scOnBoard.
  ///
  /// In en, this message translates to:
  /// **'On Board Screen'**
  String get scOnBoard;

  /// No description provided for @skip.
  ///
  /// In en, this message translates to:
  /// **'Skip'**
  String get skip;

  /// No description provided for @scanInvoice.
  ///
  /// In en, this message translates to:
  /// **'Scan invoices with '**
  String get scanInvoice;

  /// No description provided for @trackInvoice.
  ///
  /// In en, this message translates to:
  /// **'Track invoices with '**
  String get trackInvoice;

  /// No description provided for @addInvoice.
  ///
  /// In en, this message translates to:
  /// **'Add employees with '**
  String get addInvoice;

  /// No description provided for @ease.
  ///
  /// In en, this message translates to:
  /// **'ease'**
  String get ease;

  /// No description provided for @onBoardDesc.
  ///
  /// In en, this message translates to:
  /// **'Scan your invoices using HSB application'**
  String get onBoardDesc;

  /// No description provided for @getStarted.
  ///
  /// In en, this message translates to:
  /// **'Get Started'**
  String get getStarted;

  /// No description provided for @scSignIn.
  ///
  /// In en, this message translates to:
  /// **'SignIn Screen'**
  String get scSignIn;

  /// No description provided for @signIn.
  ///
  /// In en, this message translates to:
  /// **'Sign In'**
  String get signIn;

  /// No description provided for @enterInfo.
  ///
  /// In en, this message translates to:
  /// **'Enter your legal number and password'**
  String get enterInfo;

  /// No description provided for @userName.
  ///
  /// In en, this message translates to:
  /// **'User name'**
  String get userName;

  /// No description provided for @enterUserName.
  ///
  /// In en, this message translates to:
  /// **'Enter your username'**
  String get enterUserName;

  /// No description provided for @legalNumber.
  ///
  /// In en, this message translates to:
  /// **'Legal number*'**
  String get legalNumber;

  /// No description provided for @enterLegalNumber.
  ///
  /// In en, this message translates to:
  /// **'Enter your legal number'**
  String get enterLegalNumber;

  /// No description provided for @password.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get password;

  /// No description provided for @enterPassword.
  ///
  /// In en, this message translates to:
  /// **'Enter your password'**
  String get enterPassword;

  /// No description provided for @forgetPassword.
  ///
  /// In en, this message translates to:
  /// **'Forget password?'**
  String get forgetPassword;

  /// No description provided for @scForgetPassword.
  ///
  /// In en, this message translates to:
  /// **'Forget Password'**
  String get scForgetPassword;

  /// No description provided for @fillInput.
  ///
  /// In en, this message translates to:
  /// **'Fill in the input fields below'**
  String get fillInput;

  /// No description provided for @email.
  ///
  /// In en, this message translates to:
  /// **'Email address'**
  String get email;

  /// No description provided for @enterEmail.
  ///
  /// In en, this message translates to:
  /// **'Enter your email address'**
  String get enterEmail;

  /// No description provided for @rememberPassword.
  ///
  /// In en, this message translates to:
  /// **'Remember your password?'**
  String get rememberPassword;

  /// No description provided for @confirm.
  ///
  /// In en, this message translates to:
  /// **'Confirm'**
  String get confirm;

  /// No description provided for @scOtp.
  ///
  /// In en, this message translates to:
  /// **'Input OTP'**
  String get scOtp;

  /// No description provided for @fillOtp.
  ///
  /// In en, this message translates to:
  /// **'Fill in the one-time password sent to your email address'**
  String get fillOtp;

  /// No description provided for @oneTimePass.
  ///
  /// In en, this message translates to:
  /// **'One-time password'**
  String get oneTimePass;

  /// No description provided for @otpReceived.
  ///
  /// In en, this message translates to:
  /// **'Yet to receive an OTP?'**
  String get otpReceived;

  /// No description provided for @resendCode.
  ///
  /// In en, this message translates to:
  /// **'Resend code'**
  String get resendCode;

  /// No description provided for @scCreatePassowrd.
  ///
  /// In en, this message translates to:
  /// **'Create new password'**
  String get scCreatePassowrd;

  /// No description provided for @newPassowrd.
  ///
  /// In en, this message translates to:
  /// **'New password'**
  String get newPassowrd;

  /// No description provided for @confirmPassword.
  ///
  /// In en, this message translates to:
  /// **'Confirm new password'**
  String get confirmPassword;

  /// No description provided for @scHome.
  ///
  /// In en, this message translates to:
  /// **'Home Screen'**
  String get scHome;

  /// No description provided for @uploadInvoice.
  ///
  /// In en, this message translates to:
  /// **'Upload your Invoice'**
  String get uploadInvoice;

  /// No description provided for @uploadInvoiceMsg.
  ///
  /// In en, this message translates to:
  /// **'You can upload an invoice by importing or\nscanning with your camera'**
  String get uploadInvoiceMsg;

  /// No description provided for @invoices.
  ///
  /// In en, this message translates to:
  /// **'Invoices'**
  String get invoices;

  /// No description provided for @reports.
  ///
  /// In en, this message translates to:
  /// **'Reports'**
  String get reports;

  /// No description provided for @employees.
  ///
  /// In en, this message translates to:
  /// **'Employees'**
  String get employees;

  /// No description provided for @seeAll.
  ///
  /// In en, this message translates to:
  /// **'See all'**
  String get seeAll;

  /// No description provided for @allInvoices.
  ///
  /// In en, this message translates to:
  /// **'All Invoices'**
  String get allInvoices;

  /// No description provided for @allReports.
  ///
  /// In en, this message translates to:
  /// **'All Reports'**
  String get allReports;

  /// No description provided for @allEmployees.
  ///
  /// In en, this message translates to:
  /// **'All Employees'**
  String get allEmployees;

  /// No description provided for @hi.
  ///
  /// In en, this message translates to:
  /// **'Hi'**
  String get hi;

  /// No description provided for @edit.
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get edit;

  /// No description provided for @invoiceTitle.
  ///
  /// In en, this message translates to:
  /// **'Title of Invoice'**
  String get invoiceTitle;

  /// No description provided for @invoiceName.
  ///
  /// In en, this message translates to:
  /// **'Invoice name'**
  String get invoiceName;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'cancel'**
  String get cancel;

  /// No description provided for @inreview.
  ///
  /// In en, this message translates to:
  /// **'INREVIEW'**
  String get inreview;

  /// No description provided for @completed.
  ///
  /// In en, this message translates to:
  /// **'COMPLETED'**
  String get completed;

  /// No description provided for @incomplete.
  ///
  /// In en, this message translates to:
  /// **'INCOMPLETE'**
  String get incomplete;

  /// No description provided for @editProfile.
  ///
  /// In en, this message translates to:
  /// **'Edit profile'**
  String get editProfile;

  /// No description provided for @save.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get save;

  /// No description provided for @settings.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settings;

  /// No description provided for @changeLanguage.
  ///
  /// In en, this message translates to:
  /// **'Change language'**
  String get changeLanguage;

  /// No description provided for @changeLanguageMsg.
  ///
  /// In en, this message translates to:
  /// **'Toggle between muiltple languages'**
  String get changeLanguageMsg;

  /// No description provided for @notification.
  ///
  /// In en, this message translates to:
  /// **'Notification'**
  String get notification;

  /// No description provided for @noNotificationMsg.
  ///
  /// In en, this message translates to:
  /// **'No notifications yet'**
  String get noNotificationMsg;

  /// No description provided for @logout.
  ///
  /// In en, this message translates to:
  /// **'Logout'**
  String get logout;

  /// No description provided for @logoutMsg.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to logout'**
  String get logoutMsg;

  /// No description provided for @contactUs.
  ///
  /// In en, this message translates to:
  /// **'Contact Us'**
  String get contactUs;

  /// No description provided for @contactUsMsg.
  ///
  /// In en, this message translates to:
  /// **'Having any question? We are ready to help'**
  String get contactUsMsg;

  /// No description provided for @phoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Phone number'**
  String get phoneNumber;

  /// No description provided for @name.
  ///
  /// In en, this message translates to:
  /// **'Name'**
  String get name;

  /// No description provided for @message.
  ///
  /// In en, this message translates to:
  /// **'Message'**
  String get message;

  /// No description provided for @fieldRequiredMsg.
  ///
  /// In en, this message translates to:
  /// **'Field is required!'**
  String get fieldRequiredMsg;

  /// No description provided for @submitMsg.
  ///
  /// In en, this message translates to:
  /// **'Submit message'**
  String get submitMsg;

  /// No description provided for @addEmployee.
  ///
  /// In en, this message translates to:
  /// **'Add New Employee'**
  String get addEmployee;

  /// No description provided for @editEmployee.
  ///
  /// In en, this message translates to:
  /// **'Edit Employee'**
  String get editEmployee;

  /// No description provided for @firstName.
  ///
  /// In en, this message translates to:
  /// **'First Name'**
  String get firstName;

  /// No description provided for @lastName.
  ///
  /// In en, this message translates to:
  /// **'Last Name'**
  String get lastName;

  /// No description provided for @houseNumber.
  ///
  /// In en, this message translates to:
  /// **'Street/House number'**
  String get houseNumber;

  /// No description provided for @city.
  ///
  /// In en, this message translates to:
  /// **'City'**
  String get city;

  /// No description provided for @zipCode.
  ///
  /// In en, this message translates to:
  /// **'Zip code'**
  String get zipCode;

  /// No description provided for @jobType.
  ///
  /// In en, this message translates to:
  /// **'Type of job'**
  String get jobType;

  /// No description provided for @companyType.
  ///
  /// In en, this message translates to:
  /// **'Type of company'**
  String get companyType;

  /// No description provided for @bankName.
  ///
  /// In en, this message translates to:
  /// **'Bank name*'**
  String get bankName;

  /// No description provided for @iban.
  ///
  /// In en, this message translates to:
  /// **'IBAN*'**
  String get iban;

  /// No description provided for @emailMsg.
  ///
  /// In en, this message translates to:
  /// **'Wrong email format'**
  String get emailMsg;

  /// No description provided for @mobileNumber.
  ///
  /// In en, this message translates to:
  /// **'Mobile number*'**
  String get mobileNumber;

  /// No description provided for @taxId.
  ///
  /// In en, this message translates to:
  /// **'Tax ID (optional)'**
  String get taxId;

  /// No description provided for @accountantId.
  ///
  /// In en, this message translates to:
  /// **'Accountant*'**
  String get accountantId;

  /// No description provided for @notes.
  ///
  /// In en, this message translates to:
  /// **'Notes'**
  String get notes;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['ar', 'en'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar': return AppLocalizationsAr();
    case 'en': return AppLocalizationsEn();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
