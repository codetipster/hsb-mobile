import 'app_localizations.dart';

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get scOnBoard => 'On Board Screen';

  @override
  String get skip => 'Skip';

  @override
  String get scanInvoice => 'Scan invoices with ';

  @override
  String get trackInvoice => 'Track invoices with ';

  @override
  String get addInvoice => 'Add employees with ';

  @override
  String get ease => 'ease';

  @override
  String get onBoardDesc => 'Scan your invoices using HSB application';

  @override
  String get getStarted => 'Get Started';

  @override
  String get scSignIn => 'SignIn Screen';

  @override
  String get signIn => 'Sign In';

  @override
  String get enterInfo => 'Enter your legal number and password';

  @override
  String get userName => 'User name';

  @override
  String get enterUserName => 'Enter your username';

  @override
  String get legalNumber => 'Legal number*';

  @override
  String get enterLegalNumber => 'Enter your legal number';

  @override
  String get password => 'Password';

  @override
  String get enterPassword => 'Enter your password';

  @override
  String get forgetPassword => 'Forget password?';

  @override
  String get scForgetPassword => 'Forget Password';

  @override
  String get fillInput => 'Fill in the input fields below';

  @override
  String get email => 'Email address';

  @override
  String get enterEmail => 'Enter your email address';

  @override
  String get rememberPassword => 'Remember your password?';

  @override
  String get confirm => 'Confirm';

  @override
  String get scOtp => 'Input OTP';

  @override
  String get fillOtp => 'Fill in the one-time password sent to your email address';

  @override
  String get oneTimePass => 'One-time password';

  @override
  String get otpReceived => 'Yet to receive an OTP?';

  @override
  String get resendCode => 'Resend code';

  @override
  String get scCreatePassowrd => 'Create new password';

  @override
  String get newPassowrd => 'New password';

  @override
  String get confirmPassword => 'Confirm new password';

  @override
  String get scHome => 'Home Screen';

  @override
  String get uploadInvoice => 'Upload your Invoice';

  @override
  String get uploadInvoiceMsg => 'You can upload an invoice by importing or\nscanning with your camera';

  @override
  String get invoices => 'Invoices';

  @override
  String get reports => 'Reports';

  @override
  String get employees => 'Employees';

  @override
  String get seeAll => 'See all';

  @override
  String get allInvoices => 'All Invoices';

  @override
  String get allReports => 'All Reports';

  @override
  String get allEmployees => 'All Employees';

  @override
  String get hi => 'Hi';

  @override
  String get edit => 'Edit';

  @override
  String get invoiceTitle => 'Title of Invoice';

  @override
  String get invoiceName => 'Invoice name';

  @override
  String get cancel => 'cancel';

  @override
  String get inreview => 'INREVIEW';

  @override
  String get completed => 'COMPLETED';

  @override
  String get incomplete => 'INCOMPLETE';

  @override
  String get editProfile => 'Edit profile';

  @override
  String get save => 'Save';

  @override
  String get settings => 'Settings';

  @override
  String get changeLanguage => 'Change language';

  @override
  String get changeLanguageMsg => 'Toggle between muiltple languages';

  @override
  String get notification => 'Notification';

  @override
  String get noNotificationMsg => 'No notifications yet';

  @override
  String get logout => 'Logout';

  @override
  String get logoutMsg => 'Are you sure you want to logout';

  @override
  String get contactUs => 'Contact Us';

  @override
  String get contactUsMsg => 'Having any question? We are ready to help';

  @override
  String get phoneNumber => 'Phone number';

  @override
  String get name => 'Name';

  @override
  String get message => 'Message';

  @override
  String get fieldRequiredMsg => 'Field is required!';

  @override
  String get submitMsg => 'Submit message';

  @override
  String get addEmployee => 'Add New Employee';

  @override
  String get editEmployee => 'Edit Employee';

  @override
  String get firstName => 'First Name';

  @override
  String get lastName => 'Last Name';

  @override
  String get houseNumber => 'Street/House number';

  @override
  String get city => 'City';

  @override
  String get zipCode => 'Zip code';

  @override
  String get jobType => 'Type of job';

  @override
  String get companyType => 'Type of company';

  @override
  String get bankName => 'Bank name*';

  @override
  String get iban => 'IBAN*';

  @override
  String get emailMsg => 'Wrong email format';

  @override
  String get mobileNumber => 'Mobile number*';

  @override
  String get taxId => 'Tax ID (optional)';

  @override
  String get accountantId => 'Accountant*';

  @override
  String get notes => 'Notes';
}
